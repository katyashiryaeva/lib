import pandas as pd
import datetime
import deepdish as dd

def clean_df_payments():
    """
    Leave only relevant payments from debters
    """
    
    df_payments = dd.io.load('/home/fshare/rb/data_1712/hdfs/payments.h5')
    
    df_payments.delay_begin = pd.to_datetime(df_payments.delay_begin.str[1:11].values,errors='coerce')
    df_payments = df_payments[~df_payments.delay_begin.isna()].copy()
    df_payments.delay_days = df_payments.delay_days.astype(float)
    
    dd.io.save('/home/fshare/rb/data_1712/hdfs/payments_cleaned.h5',df_payments)

def get(date,
        df_payments_cleaned,
        due_days=3,
        threshold=500,
        fix_periods = False,
        fix_periods_num=4,
        ):
    """
    As payments are target variables, this function makes Y values for given date and target_type
    Returned variables are boolean, i.e. whether there will be a payment for a given time frame
    :param date
    :param df_today_portfolio
    :param df_payments_cleaned
    :param due_days
    :param threshold
    """
    date = pd.to_datetime(date)
    if fix_periods == False:
        if due_days > 0:
            due_date = date + datetime.timedelta(due_days)
            # filter only days no farther than due_days from input date
            df_payments = df_payments_cleaned.loc[(df_payments_cleaned.pmt_exec_date <= due_date) &
                                                  (df_payments_cleaned.pmt_exec_date >= date)]

        if due_days < 0:
            # filter only days no farther than due_days from input date
            df_payments = df_payments_cleaned.loc[(df_payments_cleaned.pmt_exec_date <= date) &
                                                  (df_payments_cleaned.pmt_exec_date >= (
                                                              date + datetime.timedelta(due_days)))]

        df_payments.columns = [col if not col == 'coll_ov' else 'coll_ov_{}'.format(due_days) for col in
                               df_payments.columns]

        df_payments = df_payments.groupby(['ac13_orig', 'ptdtn'])['coll_ov_{}'.format(due_days)].agg('sum').reset_index()

        df_payments.columns = ['ac13_orig', 'ptdtn', 'coll_ov_{}'.format(due_days)]
        df_payments['coll_ov_{}_num'.format(due_days)] = df_payments['coll_ov_{}'.format(due_days)]
        df_payments['coll_ov_{}'.format(due_days)] = df_payments['coll_ov_{}'.format(due_days)] >= threshold

    else:
        fix_list = []
        for i in range(1,fix_periods_num+1):
#             print('original_paym',df_payments_cleaned.shape)
            
            start_date = date-pd.Timedelta(days=30*i)
            finish_date = date-pd.Timedelta(days=30*(i-1))
            
            df_payments = df_payments_cleaned.loc[(df_payments_cleaned.pmt_exec_date <= finish_date ) &
                                                  (df_payments_cleaned.pmt_exec_date >= start_date )]
            
#             print(start_date,finish_date)
#             print(df_payments.shape)
            coll_ov,coll_total = ('coll_ov_minus_month_{}'.format(i),'coll_total_minus_month_{}'.format(i))
            
            df_payments.columns = [col if not col == 'coll_ov' else coll_ov for col in
                                   df_payments.columns]

            df_payments.columns = [col if not col == 'coll_total' else coll_total for col in
                               df_payments.columns]

            df_payments = df_payments.groupby(['ac13_orig', 'ptdtn'])[[coll_ov,coll_total]].agg('sum')#.reset_index()

            df_payments.columns = [coll_ov,coll_total]
            df_payments[[coll_ov+'_num',coll_total+'_num']] = df_payments[[coll_ov,coll_total]] 
            df_payments[coll_ov] = (df_payments[coll_ov] >= threshold).astype(int)
            df_payments[coll_total] = (df_payments[coll_total] >= threshold).astype(int)
            
            fix_list.append(df_payments.copy())
        
        fix_list = pd.concat(fix_list,axis=1).reset_index()
        df_payments = fix_list
    return df_payments.fillna(0)

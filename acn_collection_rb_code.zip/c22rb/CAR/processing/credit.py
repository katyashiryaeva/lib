import pandas as pd
from CAR import aux_functions




keys = ['ac13_orig', 
        'ptdtn',
        'id_cl',
       ]
categorical_cols_risk =   ['EDUCATION',
                         'WORK_POSITION',
                         'WORK_EMPLOYEES_CNT',
                         'WORK_IS_HEAD',
                         'RELATIONSHIP',
                         'WORK_ORG_BRANCH',
                         'VEHICLE_OWN_COUNTRY_MANUFACTUR',
                         'CLIENT_CAR_OWNER',
                         'DEPENDENTS',
                        ]
    
ready_to_make_dummies = ['HUB_ENGL',
                         'SRC_STM_ID',
                         'cusex',
                         'CLIENT_CATEGORY',
                         'CLIENT_CATEGORY_BUDGET',
                         'EDUCATION',
                         'WORK_EMPLOYEES_CNT',
                         'RELATIONSHIP',
                         'WORK_ORG_BRANCH',
                         'VEHICLE_OWN_COUNTRY_MANUFACTUR',
                         'CLIENT_CAR_OWNER',
                         'DEPENDENTS_clean',
                         'PRODUCT_ENG8N',
                         'credit_issued_year',
                         'WORK_POSITION',
                         ]

ready_numerical = ['ptsum',
                   'irat',
                   'DECLARED_AVG_MONTHLY_INCOME',
                   'AFTER_TAX_OFFICIAL_INCOME',
                   'DTI_CALC',
                   'DTI_WITH_NEW_PAYM_CALC',
                   'NEW_PAYMENT_CALC',
                   'age',
                   'WORK_IS_HEAD',
                   
                   ]

useless_in_native_form = ['ISSHORT',
                          'WORK_POSITION',
                          'OUTSTANDING',
                          ]

# Without mortgage or car credits
valid_credit_types = ['SIMPLE money',
                      'CARD with grace period',
                      'ECLoan',
                      'BIG money',
                      'OVERDRAFT on cards',
                      'CAR-classic',
                      'CAR-express',
                      'MORTGAGE',
                      ]




def dependents_clean(df_credit):
    """
    simple cleanup of a field
    """
    dep = df_credit.DEPENDENTS.astype(float)
    dep[dep >= 3] = '3+'
    return dep



def clean_df_credit(df_credit):
    """
    Cleaning and transforming string variables to make them into useful categorigal/numerical features
    Additionally preprocess it by adding ac13_orig and id_cl keys
    preliminary version
    :param df_credit
    """
    df_credit =df_credit[~(df_credit.EDUCATION=='ТЭК, добывающая промышленность')]
    df_credit.ptdtn = pd.to_datetime(df_credit.ptdtn.values)
    #df_credit = df_credit.sort_values(by = ['ac13','ptdtn','kb_date'])
    #cleaning duplicates with different 'kb_date' - they are the same credit
    df_credit = df_credit[((~df_credit.isna())[categorical_cols_risk].sum(axis=1)>=7)]
    #filtering credit_types
    df_credit.loc[df_credit.MACROPRODUCT.isin(['OVR', '-1', 'COR']), 'MACROPRODUCT'] = 'other'
    df_credit['DEPENDENTS_clean'] = dependents_clean(df_credit)
    df_credit = df_credit.loc[df_credit.PRODUCT_ENG8N.isin(valid_credit_types),:]
    
    df_credit['id_cl'] = df_credit['SRC_STM_ID'] + '/' +df_credit['ac13'].str[5:11]
    df_credit['age'] = (df_credit.ptdtn - df_credit.ptbsd).dt.days/365
    df_credit['credit_issued_year'] = df_credit.ptdtn.dt.year.astype(str)
    
    df_prof = pd.read_csv('/home/fshare/rb/misc/ros_pos_norm_okz.csv')
    prof_dict = dict(zip(df_prof['job_title'].str.strip(),df_prof['okz_x']))
    df_credit.WORK_POSITION = df_credit.WORK_POSITION.str.strip()
    df_credit.WORK_POSITION = df_credit.WORK_POSITION.map(prof_dict)
    
    #df_credit = df_credit[:].groupby(['ac13_orig','ptdtn']).last()
    df_credit.reset_index(inplace=True)
    for col in ready_numerical:
        df_credit[col] = df_credit[col].astype(str).str.replace(',', '.').astype(float)

    # Leaving only valid categorical/numerical columns
    df_credit = df_credit.loc[:, keys + ready_numerical + ready_to_make_dummies]
    df_credit = pd.get_dummies(df_credit,columns=ready_to_make_dummies, dummy_na=True)
    
    return df_credit




'''months_dict = {'April':4, 
               'August':8,
               'December':12,
               'February':2, 
               'January':1, 
               'July':7,
               'June':6, 
               'March':3, 
               'May':5,
               'November':11, 
               'October':10,
               'September':9,
              }

def make_zodiac_dict(months_dict = months_dict):
    """
    makes zodiac dict for mapping birthdate from credit_info table
    :returns dictionary with keys (1,25) where 1 - month, 25 - day
    """
    df_zodiac = pd.read_csv('/home/fshare/rb/misc/zodiac.csv',sep = ';',header = None)
    df_zodiac.columns = ['type','start','end']
    tmp_start = df_zodiac.start.str.split(' ', n = 1, expand = True) 
    tmp_end = df_zodiac.end.str.strip().str.split(' ', n = 1, expand = True) 
    df_zodiac['month_start'] = tmp_start[0].map(months_dict).astype(int)
    df_zodiac['day_start'] = tmp_start[1].astype(int)
    df_zodiac['month_end'] =tmp_end[0].map(months_dict).astype(int)
    df_zodiac['day_end'] = tmp_end[1].astype(int)
    df_zodiac.sort_values('month_start',inplace=True)
    # dict with zodiac types for mapping
    zodiac_dict = {}
    for month in range(1,13):
        for day in range(1,32):
            for row in df_zodiac.iterrows():
                row = row[1]
                if (month == row.month_start) and  (day >= row.day_start):
                    zodiac_dict[(month,day)] = row.type
                if (month == row.month_end) and  (day <= row.day_end):
                    zodiac_dict[(month,day)] = row.type   
    return zodiac_dict

zodiac_dict = make_zodiac_dict()
'''